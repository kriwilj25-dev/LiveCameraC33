package com.ibnu.livecamerac33

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.VideoCapture
import androidx.camera.video.Recording
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var imageCapture: ImageCapture
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var camera: Camera? = null
    private lateinit var executor: ExecutorService
    private var zoom2x = false
    private var isCapturing = false

    private val permissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result[Manifest.permission.CAMERA] == true) startCamera()
        else toast("Izin kamera diperlukan")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        previewView = findViewById(R.id.previewView)
        executor = Executors.newSingleThreadExecutor()

        findViewById<View>(R.id.zoomButton).setOnClickListener {
            zoom2x = !zoom2x
            camera?.cameraControl?.setZoomRatio(if (zoom2x) 2f else 1f)
            findViewById<android.widget.Button>(R.id.zoomButton).text = if (zoom2x) "1×" else "2×"
        }

        findViewById<View>(R.id.shutterButton).setOnClickListener {
            captureLivePhoto()
        }

        val needed = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (needed.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }) {
            startCamera()
        } else permissions.launch(needed)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()

            val previewBuilder = Preview.Builder()
            enableVideoStabilization(previewBuilder)
            val preview = previewBuilder.build().also {
                it.surfaceProvider = previewView.surfaceProvider
            }

            val imageBuilder = ImageCapture.Builder()
            enableVideoStabilization(imageBuilder)
            imageCapture = imageBuilder
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build()

            val recorder = Recorder.Builder()
                .setQualitySelector(
                    QualitySelector.fromOrderedList(
                        listOf(Quality.FHD, Quality.HD, Quality.SD)
                    )
                )
                .build()
            videoCapture = VideoCapture.withOutput(recorder)

            provider.unbindAll()
            camera = provider.bindToLifecycle(
                this,
                CameraSelector.DEFAULT_BACK_CAMERA,
                preview,
                imageCapture,
                videoCapture
            )

            camera?.cameraControl?.setZoomRatio(if (zoom2x) 2f else 1f)
            findViewById<android.widget.TextView>(R.id.statusText).text =
                "Siap • Live Photo 3 dtk"
        }, ContextCompat.getMainExecutor(this))
    }

    private fun <T : Any> enableVideoStabilization(builder: T) {
        // Camera2Interop asks the device camera to use optical/electronic
        // video stabilization when the Realme C33 camera HAL supports it.
        when (builder) {
            is Preview.Builder -> {
                Camera2Interop.Extender(builder).setCaptureRequestOption(
                    android.hardware.camera2.CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
                    android.hardware.camera2.CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_PREVIEW_STABILIZATION
                )
            }
            is ImageCapture.Builder -> {
                Camera2Interop.Extender(builder).setCaptureRequestOption(
                    android.hardware.camera2.CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
                    android.hardware.camera2.CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_PREVIEW_STABILIZATION
                )
            }
        }
    }

    private fun captureLivePhoto() {
        if (isCapturing) return
        val vc = videoCapture ?: return
        isCapturing = true
        findViewById<View>(R.id.shutterButton).isEnabled = false
        findViewById<android.widget.TextView>(R.id.statusText).text = "Mengambil Live Photo…"

        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val moviesDir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir
        val videoFile = File(moviesDir, "Live_${stamp}.mp4")

        val output = FileOutputOptions.Builder(videoFile).build()
        recording = vc.output
            .prepareRecording(this, output)
            .withAudioEnabled()
            .start(ContextCompat.getMainExecutor(this)) { event ->
                if (event is VideoRecordEvent.Start) {
                    takeStill(stamp)
                }
            }

        // Keep the motion clip short for stability/storage on low-end hardware.
        window.decorView.postDelayed({
            recording?.stop()
            recording = null
            isCapturing = false
            findViewById<View>(R.id.shutterButton).isEnabled = true
            findViewById<android.widget.TextView>(R.id.statusText).text = "Tersimpan"
            toast("Live Photo tersimpan")
        }, 3000)
    }

    private fun takeStill(stamp: String) {
        val name = "Live_${stamp}.jpg"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/LiveCameraC33")
        }
        val output = ImageCapture.OutputFileOptions.Builder(
            contentResolver,
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            values
        ).build()

        imageCapture.takePicture(
            output,
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onError(exception: ImageCaptureException) {
                    toast("Foto gagal: ${exception.message}")
                }
                override fun onImageSaved(result: ImageCapture.OutputFileResults) {
                    // The matching MP4 is stored in the app Movies folder.
                    // This pair is the Live Photo representation for Android.
                }
            }
        )
    }

    override fun onDestroy() {
        recording?.stop()
        recording = null
        executor.shutdown()
        super.onDestroy()
    }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
