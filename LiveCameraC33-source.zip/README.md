# Live Camera C33

Kamera Android ringan berbasis CameraX untuk Realme C33.

## Fitur
- CameraX Preview + ImageCapture + VideoCapture
- Zoom 1× / 2×
- Permintaan stabilisasi melalui Camera2Interop jika camera HAL perangkat mendukungnya
- Tombol Live Photo: menyimpan JPG + klip MP4 3 detik
- Resolusi video memilih FHD → HD → SD secara otomatis sesuai kemampuan perangkat
- Target Android 7.0+ (API 24)

## Catatan penting tentang Live Photo
Android/Realme C33 tidak memiliki satu format Live Photo universal seperti iPhone. Project ini menyimpan pasangan:
`Pictures/LiveCameraC33/Live_*.jpg` + `Movies/LiveCameraC33/Live_*.mp4`.

Implementasi ini sengaja sederhana dan ringan. Klip mulai ketika tombol ditekan, lalu foto diambil dan klip berhenti setelah 3 detik. Jadi ini adalah "motion photo style", bukan format Apple Live Photo.

## Build
1. Buka folder ini di Android Studio.
2. Biarkan Gradle mengunduh dependency.
3. Hubungkan Realme C33 dengan USB debugging aktif.
4. Build > Build APK(s).

APK debug biasanya berada di:
`app/build/outputs/apk/debug/app-debug.apk`

## Optimasi Realme C33
Jika FHD terasa berat, ubah urutan:
`Quality.HD, Quality.SD`
di `MainActivity.kt`.
