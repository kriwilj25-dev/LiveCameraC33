UPLOAD THIS FOLDER'S CONTENTS TO YOUR GITHUB REPOSITORY.

It contains the source ZIP and a GitHub Actions workflow that extracts and builds it.
After upload, open Actions -> Build LiveCameraC33 APK -> Run workflow.
When finished, open the workflow run and download the artifact named LiveCameraC33-debug-apk.
